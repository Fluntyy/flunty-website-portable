import{w as o}from"./index.B-uIOJ_6.js";const t=o(0),s=o(1);export{t as f,s as o};
