import{a as t}from"../chunks/entry.DBFy1WVT.js";export{t as start};
